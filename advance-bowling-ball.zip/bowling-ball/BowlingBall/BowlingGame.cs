﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingBall
{
    public abstract class BowlingGame
    {
        #region constant declaration

        //Maximum possible score is 300 for Bowling Game
        protected const int _maxScore = 300;

        //Minimum 0 pins bowler can knock down - knows as Foul in Bownling Game
        protected const int _minPins = 0;

        //Maximum 10 pins bowler can knock down - knows as Strike/Spare in Bownling Game
        protected const int _maxPins = 10;

        //Maximum 10 frames are allowed in Bowling Game - Each frame has two balls (last frame has 3 balls)
        protected const int _maxFrame = 10;

        #endregion

        //private int score = 0;

        //public int Score
        //{
        //    get
        //    {
        //        return score;
        //    }

        //    set
        //    {
        //        score = value;
        //    }
        //}

        #region field declaration
        public Frame[] frame;
        #endregion

        #region concrete/non-concrete methods
        public abstract void Roll(byte ball);

        public abstract int GetFrameScore(int frameNumber);

        public abstract int GetTotalBallPlayed();

        public abstract int GetTotalFramePlayed();
        #endregion
    }
}