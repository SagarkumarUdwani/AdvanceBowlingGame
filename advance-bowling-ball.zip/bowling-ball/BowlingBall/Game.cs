﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingBall
{
    public class Game : BowlingGame, IGame
    {
        /*
        Possible Solutions but can cause an issue
        Approach 1 : Variable Shuffling
        Approach 2 : Using Array of Array
        Approach 3 : List of Dictionary
        //Approach 4  : Array of rolls
        */

        int lastFrameIndex = 0;
        int lastBallIndex = 0;

        public Game()
        {
            //Frame Initialization
            frame = new Frame[_maxFrame];
        }

        public Game(string playerName)
        {
            //frame = new Frame[_maxFrame];

            //Player p1 = new Player();
            //p1.player = playerName;
            //p1.Frame = frame;
        }

        /// <summary>
        /// Pins knock down while throwing a ball
        /// </summary>
        /// <param name="pins"></param>
        public override void Roll(byte pins)
        {
            //Frame based calculation
            if (pins < _minPins)
                pins = _minPins;
            else if (pins > _maxPins)
                pins = _maxPins;

            try
            {
                if (frame[lastFrameIndex] == null)
                    frame[lastFrameIndex] = new Frame();

                if (frame[lastFrameIndex].balls == null)
                {
                    if (lastFrameIndex == _maxFrame-1)
                        frame[lastFrameIndex].balls = new byte?[3];
                    else
                        frame[lastFrameIndex].balls = new byte?[2];
                }

                frame[lastFrameIndex].balls[lastBallIndex] = pins;
                lastBallIndex++;

                IncreaseFrameIndex(frame[lastFrameIndex]);
            }
            catch (IndexOutOfRangeException ex)
            {
                //Warning : Maximum frame limit reached
            }
        }

        /// <summary>
        /// Get Score for given frame
        /// </summary>
        /// <param name="frameNumber"></param>
        /// <returns>int</returns>
        public override int GetFrameScore(int frameNumber)
        {
            try
            {
                return frame[frameNumber - 1].frame_Score;
            }
            catch
            {
                return 0;
            }
        }

        /// <summary>
        /// Get total number of balls played
        /// </summary>
        /// <returns>int</returns>
        public override int GetTotalBallPlayed()
        {
            int count = 0;

            foreach (var item in frame.Where(x => x != null))
            {
                count += item.balls.Count(v => v != null);
            }
            return count;
        }
        /// <summary>
        /// Get total number of frames played by bowler
        /// </summary>
        /// <returns>int</returns>
        public override int GetTotalFramePlayed()
        {
            return frame.Where(x => x != null).Count();
        }

        /// <summary>
        /// Get total score of the Game
        /// </summary>
        /// <returns>int</returns>
        public int GetTotalScore()
        {
            // Calculate the final score of the game
            int score = 0;

            for (int i = 0; i < _maxFrame; i++)
            {
                if (frame[i] != null)
                {
                    if (IsStrike(frame[i]))
                    {
                        score += CalculateStrikeScore(i);
                    }
                    else if (IsSpare(frame[i]))
                    {
                        score += CalculateSpareScore(i);
                    }
                    else
                    {
                        score += CalculateStandardScore(i);
                    }

                    frame[i].frame_Score = score;
                }
            }

            return (score > _maxScore ? _maxScore : score) ;
        }

        /// <summary>
        /// If a bowler is able to knock down all pins with first ball of a frame
        /// </summary>
        /// <param name="frame"></param>
        /// <returns>bool</returns>
        private bool IsStrike(Frame frame)
        {
            return (frame != null && frame.balls != null && frame.balls[0] != null && frame.balls[0] == _maxPins);
        }

        /// <summary>
        /// If the bowler is able to knock down all pins with two balls of a frame
        /// </summary>
        /// <param name="frame"></param>
        /// <returns>bool</returns>
        private bool IsSpare(Frame frame)
        {
            return (IsValidFrane(frame) && (frame.balls[0] + frame.balls[1] == _maxPins));
        }
       
        /// <summary>
        /// Total pins knock down by bowler in current frame i.e. Ball 1 + Ball 2
        /// </summary>
        /// <param name="index"></param>
        /// <returns>int</returns>
        private int CalculateStandardScore(int index)
        {
            return GetPins(index, 0) + GetPins(index, 1);
        }

        /// <summary>
        /// Bonus points are awarded for Strike depending on what is scored in the next 2 balls
        /// </summary>
        /// <param name="frameNumber"></param>
        /// <returns>int</returns>
        private int CalculateStrikeScore(int index)
        {
            if (index == _maxFrame - 2)
                return GetPins(index, 0) + GetPins(index + 1, 0) + GetPins(index + 1, 1);
            else if (index == _maxFrame - 1)
                return GetPins(index, 0) + GetPins(index, 1) + GetPins(index, 2);
            else
                return GetPins(index, 0) + GetPins(index + 1, 0) +
                    (GetPins(index + 1, 0) == _maxPins ? GetPins(index + 2, 0) : GetPins(index + 1, 1));
        }

        /// <summary>
        /// Bonus points are awarded for Spare depending on what is scored in the next 1 ball
        /// </summary>
        /// <param name="frameNumber"></param>
        /// <returns>int</returns>
        private int CalculateSpareScore(int index)
        {
            return GetPins(index, 0) + GetPins(index, 1) + 
                (index == _maxFrame - 1 ? GetPins(index, 2) : GetPins(index + 1, 0));
        }

        /// <summary>
        /// Get pins for given Ball from the Frame
        /// </summary>
        /// <param name="frameNumber"></param>
        /// <param name="ballNumber"></param>
        /// <returns>int</returns>
        private int GetPins(int index, int ball)
        {
            if (frame[index] != null && frame[index].balls != null && frame[index].balls[ball] != null)
                return (int)frame[index].balls[ball];
            else
                return 0;
        }

        private static bool IsValidFrane(Frame frame)
        {
            return (frame != null && frame.balls != null && frame.balls[0] != null && frame.balls[1] != null);
        }

        private void IncreaseFrameIndex(Frame frame)
        {
            if (lastFrameIndex < _maxFrame - 1)
            {
                if (IsStrike(frame))
                {
                    lastFrameIndex++;
                    lastBallIndex = 0;
                }
                else if (IsValidFrane(frame))
                {
                    lastFrameIndex++;
                    lastBallIndex = 0;
                }
            }
        }

        /*
        private int CalculateSpareScore(int rollIndex)
        {
            return 10 + rolls[rollIndex + 2];
        }

        private int CalculateStrikeScore(int rollIndex)
        {
            return 10 + rolls[rollIndex + 1] + rolls[rollIndex + 2];
        }
        */
    }
}