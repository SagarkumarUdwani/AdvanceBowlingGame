﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingBall
{
    public class Player
    {
        public string playerName;

        public string contactNumber;

        public string emailId;

        public Frame frame;
    }
}
