﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingBall
{
    public class Frame
    {
        //To hold pins data
        public byte?[] balls { get; set; }

        //Total score per Frame
        public int frame_Score { get; set; }
    }
}
